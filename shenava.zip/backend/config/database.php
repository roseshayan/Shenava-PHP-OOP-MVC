<?php

/**
 * Shenava - Database Configuration
 */

return [
    'host' => 'localhost',
    'database' => 'shenava_db',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8', // حتما utf8 باشه
    'prefix' => ''
];